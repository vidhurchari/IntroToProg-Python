# ------------------------------------#
# Title: Assignment07.py
# Desc: This script performs basic math operations, handles errors and pickels data
# Change Log:
# 8.31.2019: Created script
# ------------------------------------#


# Step 1: Gather first number
import pickle
UserName = input("Enter name: ")
try:
    FirstNumber = float(input("Input your 1st number:"))
except Exception as e1:
    print(e1)
    print("Error belongs to the following class: ", e1.__class__)
    exit()

# Step 2: Gather second number from user
try:
    SecondNumber = float(input("Input your 2nd number:"))
except Exception as e2:
    print(e2)
    print("Error belongs to the following class: ", e2.__class__)
    exit()

# Step 3: Calculate results of adding, subtracting, multiplying and dividing the 2 numbers
FirstNumberPlusSecondNumber = FirstNumber + SecondNumber
FirstNumberMinusSecondNumber = FirstNumber - SecondNumber
FirstNumberTimesSecondNumber = FirstNumber * SecondNumber
try:
    FirstNumberDividedBySecondNumber = FirstNumber / SecondNumber
except Exception as e3:
    print(e3)
    print("Error belongs to the following class: ", e3.__class__)
try:
    AbsoluteFirstNumberDividedBySecondNumber = int(FirstNumber / SecondNumber)
except Exception as e4:
    print(e4)
    print("Error belongs to the following class: ", e4.__class__)
try:
    RemainderOfFirstNumberDividedBySecondNumber = FirstNumber % SecondNumber
except Exception as e5:
    print(e5)
    print("Error belongs to the following class: ", e5.__class__)

# Step 4: Display results of adding, subtracting, multiplying and dividing the 2 numbers
print("\n The sum of the two numbers is", FirstNumberPlusSecondNumber)
print("\n Subtracting the second number from the first gives us", FirstNumberMinusSecondNumber)
print("\n The product of the two numbers is", FirstNumberTimesSecondNumber)
print("\n Dividing the first number by the second number gives us a quotient of", FirstNumberDividedBySecondNumber)
if (RemainderOfFirstNumberDividedBySecondNumber > 0):
    print("\n The absolute value of dividing the first number by the second number is",
          AbsoluteFirstNumberDividedBySecondNumber,
          "& the remainder is", RemainderOfFirstNumberDividedBySecondNumber)

# Step 5: Save pickled values to file
objfile = open("DataInputs.txt", "ab+")
UserChoice=int(input("Enter 1 to save these calculations to file"))
if UserChoice == 1:
    FileDump = [UserName, FirstNumber, SecondNumber]
    pickle.dump(FileDump, objfile)
    objfile.close()

objfile = open("DataInputs.txt", "rb")
print("Previous calcs include:")
while True:
    try:
        o = pickle.load(objfile)
        print(o)
    except EOFError:
        break
objfile.close()

input("\n Thanks for using the most primitive calculator in the world! \n \nHit enter to end")

